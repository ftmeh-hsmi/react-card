fetch('https://fakestoreapi.com/products')
  .then(res => res.json())
  .then(json => render(json))



 function render(products){
  const template= products.map( product =>{
    const {title,price,image}=product;
    return`
    <div class="card">
      <img src="${image}" alt="" />
      <div class="desc">
        <h3>${title}</h3>
        <span>${price}</span>
      </div>
    </div>

    `
  })

 }     